<pre><?php

/*
⚠️ DANGER! This is a prototype. Use at your own risk.

Current Version: 2025-09-24_05.45
Invented by: Wolfmond

This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <https://unlicense.org/>
*/

$injuries = array(
'Schwerer Verkehrsunfall auf der A28 nahe der Abfahrt Oldenburg-Ost; mehrere eingeklemmte Personen.',
'Arbeitsunfall in der Chemiefabrik mit Herzstillstand und lebensbedrohlicher Rauchinhalation.',
'Sturz eines Bauarbeiters von einem Krangerüst in der Innenstadt; schwere Schädelverletzung.',
'Herzinfarkt bei einer Marathonläuferin im Schlossgarten; High-Priority Transport ins Zentrum.',
'Schiffsunfall im Hafen mit unterkühltem, bewusstlosem Matrosen.',
'Mehrfachverletzte bei Brand in einem Mehrfamilienhaus in Kreyenbrück.',
'Schwerer Motorradunfall auf der Oldenburger Straße mit offener Fraktur.',
'Bewusstloser Taucher im Kanal mit Verdacht auf Dekompressionsunfall.',
'Massenkarambolage bei Nebel auf der B211; mehrere Schwerverletzte.',
'Stromschlag in einer Werkstatt; Patient mit schweren Verbrennungen und Herzrhythmusstörungen.',
'Schweres Asthma beim Kind auf einem abgelegenen Bauernhof; schneller Lufttransport nötig.',
'Schwerer Sturz von einer Pferdekutsche bei Pferderennenveranstaltung auf dem Fliegerdeich.',
'Akute Blutung nach Schussverletzung (fiktiv) auf einem Industriegelände — sofortiger Transport.',
'Chemikalienfreisetzung in einer Lagerhalle; Patient mit Inhalationsschäden.',
'Hochbetagte Person mit Schlaganfall in einem weit abgelegenen Pflegeheim.',
'Helikoptertransfer eines Neugeborenen mit angeborener Herzfehlbildung ins Spezialklinikum.',
'Massenpanik bei Konzert auf dem Freigelände; mehrere Traumata und Schnittverletzungen.',
'Einsturz einer Lagerhalle mit Verschütteten in Wechloy.',
'Schwerer Fahrradsturz am Haarenufer mit spinaler Verletzung vermutet.',
'Binnenschiff kollidiert mit Brückenpfeiler; Besatzungsmitglied eingeklemmt.',
'Gasaustritt in Wohnhaus; mehrere Anwohner bewusstlos.',
'Brandausbruch in Pflegeheim; Evakuierung per Hubschrauber für kritisch Kranke.',
'Verschüttung in einem Silo; Arbeiter atmet giftige Stäube ein.',
'Lebensbedrohliche allergische Reaktion (anaphylaktischer Schock) in einer ländlichen Gemeinde.',
'Hochrisiko-Geburt auf einem Frachtschiff im Hafen — schneller Lufttransport nötig.',
'Extremer Hitzschlag bei Arbeiten auf einer Deponie; Kreislaufkollaps.',
'Schwere Verbrennungen nach Verpuffung in einer Biogasanlage.',
'Gestochenes Kind mit anaphylaktischem Schock bei einem Ausflug im Eversten Holz.',
'Person in Lebensgefahr nach Sturz vom Deich bei starkem Seegang (Küstengebiet Anbindung).',
'Schusswechsel (fiktiv) mit mehreren Verletzten bei einer Straßenschlacht — Luftunterstützung für schnellen Transport.',
'Schwere Beinverletzung nach Fußgänger-gegen-Bus-Unfall am ZOB.',
'Bewusstloser Wanderer mit Unterkühlung im Schlosspark bei Nacht.',
'Herzrhythmusstörung nach Elektrounfall auf einem Schiff im Küstenhafen.',
'Schweres Schädel-Hirn-Trauma nach Sprung in seichtes Wasser am Hafenbecken.',
'Vergiftung durch Ingestion von Industriechemikalien in einem Lagerbetrieb.',
'Lebensbedrohliche innere Blutung nach Sturz in einem Steinbruch nahe Oldenburg.',
'Schlaganfall bei einem Altenheim-Patienten auf einem abgelegenen Gehöft.',
'Akute Intoxikation nach Drogenüberdosis mit Atemstillstand in der Innenstadt.',
'Panikattacke mit Herzstillstand bei einem Großevent im Weser-Ems-Hallen-Areal.',
'Gefahrgutunfall beim Bahntransport durch Oldenburg mit Rauchentwicklung; mehrere Verletzte.',
'Heli-Evakuierung nach Hochwasser: isolierte Siedlung nicht erreichbar per Straße.',
'Schwer verletzter Kletterer an einem Industriekran im Betriebsgelände.',
'Atemstillstand nach Ertrinkungsunfall in einem Seitenarm der Hunte.',
'Multiple Verletzte nach Explosion in Schrotthandelanlage.',
'Akuter Herzinfarkt auf dem Messegelände während einer Ausstellung.',
'Schwerer Stoß mit landwirtschaftlichem Gerät auf einem abgelegenen Hof; starke Blutung.',
'Landeplatz-Notfall: Patient bewusstlos auf Dachterrasse eines Parkhauses, bodengebunden schwer erreichbar.',
'Intoxikation durch CO-Vergiftung in einer Tiefgarage; mehrere Menschen betroffen.',
'Niedergeschlagener Bauarbeiter in einer Tunnelbaustelle mit Lebensgefahr.',
'Schweres Schädeltrauma nach Gewaltvorfall (fiktiv) in einer Diskothek.',
'Mutter mit Komplikationen in der Spätschwangerschaft auf einer Offshore-Versorgungsanlage im Hafen.',
'Brodelnder Brand in einer Autowerkstatt; Eingeschlossene mit Rauchgasintoxikation.',
'Mehrere Schwerverletzte nach Stallbrand auf einem Reiterhof.',
'Akuter Nierenversagen eines Patienten in einer abgelegenen Ferienanlage — schneller Transport nötig.',
'Person unter eingestürztem Dach nach Unwetter in einer Außenstelle.',
'Sturz vom Fahrrad während einer Schulklasse-Exkursion mit Bewusstseinsverlust.',
'Kreislaufkollaps nach extremer Unterkühlung bei einer Wattwanderung (Anbindung an Insel-/Küstenbereiche).',
'Sepsis-Verdacht mit rascher Verschlechterung in einem Landarztpraxis-Bezirk.',
'Bewusstloser Arbeiter in einer Kühlhalle mit Hypothermie.',
'Schwere Augenverletzung nach Chemikalienkontakt in einer Lackiererei.',
'Panzerungsspiel (fiktiv) — Explosion bei Industrietestgelände mit mehreren Schwerverletzten.',
'Person mit offener Bauchverletzung nach Sturz in einer Baustelle.',
'Mehrfachverletzte nach Zusammenstoß zweier Reisebusse vor dem Hauptbahnhof.',
'Schwerer Kreislaufkollaps bei Großveranstaltung am Pferdemarkt wegen Überhitzung.',
'LKW-Fahrer mit Herzstillstand auf einer Brücke — Straßenblockade, Heli bevorzugt.',
'Verschüttung in Baugrube; potenziell Atemnot und Frakturen.',
'Bewusstloser nach Stromunfall an einer Bahnanlage.',
'Akute Vergiftung eines Kindes nach Aufnahme unbekannter Substanz in einem Gartenverein.',
'Schwerer Sturz von einer Windkraftanlage im Außenbereich von Oldenburg.',
'Atemstillstand nach Rauchgasinhalation bei Lagerhallenbrand im Gewerbepark.',
'Schwere Beinverletzung nach Sturz beim Mountainbiken im Umland.',
'Traumatische Amputation nach Unfall mit Bandsäge in Schreinerei.',
'Zusammenbruch mehrerer Arbeiter bei Hitzschlag in einer Asphaltmischanlage.',
'Tiefgreifende Unterkühlung eines Seglers, der nahe dem Hafen gekentert ist.',
'Vergiftung durch Pilzaufnahme bei einer Wandergruppe im Naherholungsgebiet.',
'Personen nach Massenpanik auf Fußgängerbrücke mit Crush-Injuries.',
'Schwerer Sturz eines Kindes von einer Schleuse im Kanalbereich.',
'Patient mit schwerer Verbrennung nach Grill-Explosionsunfall auf einer Werft.',
'Akuter Herzinfarkt bei Fußballspiel in einem Amateurstadion mit schlechter Bodenanbindung.',
'Person von Zug erfasst; ausgeprägte Polytraumen nahe Bahnhofsvorplatz.',
'Intoxikation nach Gasausstrom in einer Schule; Schüler mit Atemnot.',
'Schwerer Fahrradunfall bei Nacht auf der Umgehungsstraße mit Blutverlust.',
'Person bewusstlos in abgelegener Bootshütte am Hafenarm; schlechter Straßenzugang.',
'Schwerer Arbeitsunfall in Sägewerk mit Kopfverletzung und Blutverlust.',
'Lebensbedrohliche innere Verletzung nach Sturz von Stallbalken auf Hof.',
'Patient mit akuter Vergiftung nach Inhalation von Lösungsmitteln in Lackfabrik.',
'Sturz eines Kletters von der Fassade beim Fassadenreinigungsauftrag.',
'Mehrere Verletzte nach massiver Überflutung einer Tiefgarage; Evakuierung per Luft.',
'Person in kritischem Zustand nach Stromschlag an 110-kV-Anlage im Außenbereich.',
'Verdacht auf Lungenembolie bei Joggerin in einem abgelegenen Naturschutzgebiet.',
'Schwerer Sportunfall mit Wirbelsäulenverletzung in einer Schulturnhalle außerhalb Ortskern.',
'Akute Blutung nach Explosion einer Gasflasche bei Schweißarbeiten in einem Hinterhof.',
'Mehrere Betroffene nach Zusammenbruch bei Firmenfeier durch unspezifische Vergiftung.',
'Patient mit schwerer Atemnot bei Industriebrand in Gewerbegebiet Küstenstraße.',
'Hochrisiko-Geburt in naturferner Ferienwohnung entlang eines Seitenarms.',
'Sturz in eine Schleuse mit langen Rettungswegen und kritischem Zustand.',
'Lebensbedrohlicher Blutdruckentgleisung (Hypertensive Krise) bei älterem Patienten auf abgelegener Siedlung.',
'Schwerer Schädeltrauma nach Auseinandersetzung (fiktiv) in einem Park bei Nacht.',
'Eingeklemmte Person nach Unfall mit landwirtschaftlichem Anhänger auf Feldweg.',
'Massenanfall von Verletzten nach Busbrand auf Landstraße; Heli als Evakuierungsachse erforderlich.');

$hospitals = array(
	'Pius-Hospital Oldenburg|53.144026, 8.211016',
	'Elisabeth-Kinderkrankenhaus|53.11162333215605, 8.214496970028078',
	'Evangelisches Krankenhaus|53.142950679739, 8.204456652779054',
	'Pius-Hospital|53.14385714473953, 8.210912268834155',
	'Klinikum Oldenburg AöR|53.11215837380228, 8.215650517991655',
	);


$text_koordinate = '53.144026, 8.211016';        // Default für Injuries
$hospital_koordinate = '53.143746, 8.242525';    // Default für Hospitals

$text_koordinate = '53.144026, 8.211016';        // Default für Injuries
$hospital_koordinate = '53.143746, 8.242525';    // Default für Hospitals

$result = array();

foreach ($injuries as $injury) {
    // --- Injury ---
    if (strpos($injury, '|') !== false) {
        list($text, $coords) = explode('|', $injury, 2);
        list($lat, $lng) = array_map('trim', explode(',', $coords));
    } else {
        $text = $injury;
        list($lat, $lng) = array_map('trim', explode(',', $text_koordinate));
    }

    // --- Hospital zufällig auswählen ---
    $hospital = $hospitals[array_rand($hospitals)];
    if (strpos($hospital, '|') !== false) {
        list($hName, $hCoords) = explode('|', $hospital, 2);
        list($hLat, $hLng) = array_map('trim', explode(',', $hCoords));
    } else {
        $hName = $hospital;
        list($hLat, $hLng) = array_map('trim', explode(',', $hospital_koordinate));
    }

    // --- Szenario zusammenbauen ---
    $result[] = array(
        //'text' => $text . " Bitte zum $hName bringen.",
        'text' => $text,
        'location' => array((float)$lat, (float)$lng),
        'hospital' => array(
            'name' => $hName,
            'location' => array((float)$hLat, (float)$hLng)
        )
    );
}

// JSON ausgeben (schön formatiert)
echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>